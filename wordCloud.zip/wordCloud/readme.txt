1. 点击 home.html 直接在浏览器打开
2. 主要的文件依赖为: wordcloud2.js, home.js, home.css
3. 依赖的库有(引用了外部CDN): bootstrap, jQuery
4. API.json 属于接口说明文档
5. document.txt 属于词云图说明文档
6. 其他文件属于说明文档
